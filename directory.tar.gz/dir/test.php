<?php
//require_once('license.php');
require_once'./rkhunter/rkh_config.php';
require_once('index/header.php');
require_once('./rkhunter/rkhunter_function.php');
?>
<style>
    .relative-submit {
        position: relative;
        top: -50px;
        left: -100px;
        background-color: white;
        width: 500px;
    }


    .relative {
        position: relative;
        top: -5px;
        left: 0px;
        background-color: white;
        width: 0px;
    }

    .relative-remove{
        position: relative;
        top: -35px;
        left: 300px;
        background-color: white;
        width: 0px

    }

    .settings
    {
        margin-top:-20px;
    }

</style>


<section class="content">
    <section class="content-header">
        <h1>
            RK Hunter
            <small style="float:right;">v1.0.0</small>
        </h1>

    </section>
    <!-- Content Header (Page header) -->

    <section>
        <?php include_once('./rkhunter/tab-menu.php') ?>
        <div class="box box-primary">

            <div class="box-body">

                <div class="row">
                    <div class="panel-heading">
                        <div class="box-header">
                            <h3 class="box-title"><i class="fa fa-list"></i>
                                &nbsp;&nbsp;Settings
                            </h3>
                        </div>
                    </div>
                </div>




                    <div class="row">
                        <div class="col-md-6">
                        <div class="box box-primary">
                            <div class="box-header" >
                                <i class="fa fa-list" aria-hidden="true"></i>
                                <h3 class="box-title">Email Settings</h3>
                            </div>
                            <div class="box-body">
                                <form class="form-inline" action='<?php $_server[PHP_SELF] ?>' method='post'>
                                    Email address: <input type='email' style="width: 100%;margin: 5px 0" class="form-control" name='email_address'>

                                    <input class="btn-primary btn fa-input" type='submit' value='Submit'>

                                </form>



                                <?php
                                if(isset($_POST['email_address'])){
                                    add_email($_POST['email_address']);
                                }

                                if(isset($_POST['remove_email'])){
                                    remove_email();
                                }
                                ?>

                                <div class="panel panel-default" style="margin-top: 15px;">
                                    <div class="panel-heading">
                                        <?php if(!file_exists('/usr/local/cpanel/whostmgr/cgi/'.$rkh_folder.'/rkhunter/email_addr')){
                                            echo "<span style='color:red;'>No email provided</span>";
                                        }
                                        else{
                                            echo(exec('cat /usr/local/cpanel/whostmgr/cgi/'.$rkh_folder.'/rkhunter/email_addr'));
                                        }
                                        ?>

                                    </div>
                                </div>
                                <form action="<?php $_server[PHP_SELF] ?>" method="post">
                                    <input class="btn-primary btn fa-input"  type="submit" name='remove_email' value='Remove Email' />
                                </form>
                            </div>
                        </div>
                        </div>
                        <div class="col-md-6">

                            <div class="box box-primary">
                                <div class="box-header" >
                                    <i class="fa fa-list" aria-hidden="true"></i>
                                    <h3 class="box-title">Update RKhunter</h3>
                                </div>
                                <div class="box-body">
                                    <form action="<?php $_server[PHP_SELF]?>" method="post" style="width: 100%">
                                        <input class="btn btn-primary" type="submit" id="update_rkhunter" style="margin: auto;display: block" name='update_rkhunter' value='Update RKhunter'></br>
                                    </form>

                                    <?php
                                    require_once('./rkhunter/rkhunter_function.php');

                                    if(isset($_POST['update_rkhunter'])){
                                        update_rkhunter();
                                    }
                                    ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                        <div class="box box-primary">
                            <div class="box-header" >
                                <i class="fa fa-list" aria-hidden="true"></i>
                                <h4 class="box-title">Daily Scan Cron</h4>
                            </div>
                            <div class="row">
                                <form class="col-xs-6" action="<?php $_server[PHP_SELF]?>" method="post">
                                    <div class="form-group">
                                        <input class="btn btn-primary" type="submit" name='add_cron' value='Add Cron' style="margin-left: 15%;">
                                    </div>
                                </form>


                                <form class="col-xs-6" action="<?php $_server[PHP_SELF]?>" method="post">
                                    <div class="form-group">
                                        <input class="btn btn-primary" type="submit" name='remove_cron' value='Remove Cron'>
                                    </div>
                                </form>
                            </div>
                            <?php
                            require_once('./rkhunter/rkhunter_function.php');

                            if(isset($_POST['add_cron'])){
                                add_cron();
                            }

                            if(isset($_POST['remove_cron'])){
                                remove_cron();
                            }
                            ?>

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <?php
                                    if (file_exists('/etc/cron.daily/aast_rkhunter.sh')){
                                        echo "<span style='color:green;'>Daily Auto Scan Is Active</span>";
                                    }
                                    else {
                                        echo "<span style='color:brown;'>Alert! Daily Scan is not Active<span>";
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>




                <!--
   <div class="col-sm-5">
                <div class="box box-primary">
                    <div class="box-header" >
                        <i class="fa fa-list" aria-hidden="true"></i>
                        <h4 class="box-title">Daily Scan Cron</h4>
                    </div>
                    <div class="box-body">
                      <form action="<?php $_server[PHP_SELF]?>" method="post">
                        <input class="btn btn-primary" type="submit" name='add_cron' value='Add Cron'></br>
                      </form>

                    <div class = relative-remove>
                      <form action="<?php $_server[PHP_SELF]?>" method="post">
                        <input class="btn btn-primary" type="submit" name='remove_cron' value='Remove Cron'></br>
                      </form>
                    </div>
                      <?php
                require_once('./rkhunter/rkhunter_function.php');

                if(isset($_POST['add_cron'])){
                    add_cron();
                }

                if(isset($_POST['remove_cron'])){
                    remove_cron();
                }
                ?>

                    <div class="panel panel-warning">
                    <div class="panel-heading">
                    <?php
                if (file_exists('/etc/cron.daily/aast_rkhunter.sh')){
                    echo "Daily Auto Scan Is Active";
                }
                else {
                    echo "Alert! Daily Scan is not Active";
                }
                ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>

-->


            </div>

        </div>

    </section><!-- /.content -->
</section><!-- /.right-side -->


<?php
require_once('index/footer.php');
?>
